INSERT INTO topic (name, description, text_field1, text_field2)
VALUES
('Food',
'
Topic containing words related to food
',
'
Hamburger
',
'
Pasta
'
),
('Computer Parts',
'
Topic containing words related to computer parts
',
'
CPU
',
'
GPU
'
),
('Animals',
'
Topic containing words related to animals
',
'
Tiger
',
'
Lion
'
);





